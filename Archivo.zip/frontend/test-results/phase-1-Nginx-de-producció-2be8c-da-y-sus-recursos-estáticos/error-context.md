# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase-1.spec.js >> Nginx de producción sirve una ruta profunda y sus recursos estáticos
- Location: e2e/phase-1.spec.js:29:1

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.channel-title')
Expected substring: "Instagram"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" locator('.channel-title') with timeout 5000ms
  - waiting for locator('.channel-title')

```

```yaml
- main:
  - text: am
  - heading "Inicia sesión" [level=1]
  - paragraph: Ingresa a AI Marketing Manager con tu cuenta.
  - text: Correo electrónico
  - textbox "Correo electrónico"
  - text: Contraseña
  - textbox "Contraseña"
  - button "Ingresar"
  - link "Continuar con Google":
    - /url: /api/auth/google
  - link "¿Olvidaste tu contraseña?":
    - /url: /forgot-password
```

# Test source

```ts
  1   | import { expect, test } from '@playwright/test';
  2   | 
  3   | const browserErrors = new WeakMap();
  4   | test.beforeEach(async ({ page }) => {
  5   |   const errors = [];
  6   |   browserErrors.set(page, errors);
  7   |   page.on('pageerror', (error) => errors.push(error.message));
  8   |   page.on('console', (message) => { if (message.type() === 'error') errors.push(message.text()); });
  9   | });
  10  | test.afterEach(async ({ page }) => {
  11  |   expect(browserErrors.get(page), 'No debe haber errores JavaScript ni errores de consola').toEqual([]);
  12  | });
  13  | 
  14  | test('navega a los once módulos desde el sidebar', async ({ page }) => {
  15  |   const entries = [
  16  |     ['Dashboard', '/'], ['Facebook', '/channels/facebook'], ['Instagram', '/channels/instagram'],
  17  |     ['TikTok', '/channels/tiktok'], ['Comparación', '/comparison'], ['Reportes', '/reports'],
  18  |     ['Inteligencia Artificial', '/ai'], ['WhatsApp', '/whatsapp'], ['Conexiones', '/connections'],
  19  |     ['Usuarios', '/users'], ['Ajustes', '/settings'],
  20  |   ];
  21  |   await page.goto('/');
  22  |   for (const [label, path] of entries.slice(1)) {
  23  |     await page.getByRole('link', { name: label, exact: true }).click();
  24  |     await expect(page).toHaveURL(new RegExp(`${path.replaceAll('/', '\\/')}\\/?$`));
  25  |     await expect(page.locator('main h1').first()).toBeVisible();
  26  |   }
  27  | });
  28  | 
  29  | test('Nginx de producción sirve una ruta profunda y sus recursos estáticos', async ({ page }) => {
  30  |   const failedResources = [];
  31  |   page.on('response', (response) => {
  32  |     if (['script', 'stylesheet', 'image'].includes(response.request().resourceType()) && response.status() >= 400) {
  33  |       failedResources.push(`${response.status()} ${response.url()}`);
  34  |     }
  35  |   });
  36  |   const response = await page.goto('/channels/instagram');
  37  |   expect(response?.status()).toBe(200);
  38  |   await expect(page.locator('main h1').first()).toBeVisible();
> 39  |   await expect(page.locator('.channel-title')).toContainText('Instagram');
      |                                                ^ Error: expect(locator).toContainText(expected) failed
  40  |   expect(failedResources).toEqual([]);
  41  | });
  42  | 
  43  | test('busca módulos, usuarios y publicaciones y navega al resultado', async ({ page }) => {
  44  |   await page.goto('/');
  45  |   const search = async (term) => {
  46  |     await page.getByRole('button', { name: 'Buscar' }).click();
  47  |     const input = page.getByRole('textbox', { name: 'Buscar módulos, usuarios y publicaciones' });
  48  |     await input.fill(term);
  49  |   };
  50  | 
  51  |   await search('Instagram');
  52  |   await page.getByRole('option').filter({ hasText: 'Módulo' }).first().click();
  53  |   await expect(page).toHaveURL(/\/channels\/instagram$/);
  54  | 
  55  |   await search('Sofía Ramírez');
  56  |   await page.getByRole('option').filter({ hasText: 'Usuario' }).click();
  57  |   await expect(page).toHaveURL(/\/users$/);
  58  |   await expect(page.getByPlaceholder('Buscar usuario')).toHaveValue('Sofía Ramírez');
  59  | 
  60  |   await search('Pequeños momentos');
  61  |   await page.getByRole('option').filter({ hasText: 'Publicación' }).click();
  62  |   await expect(page).toHaveURL(/\/reports$/);
  63  |   await expect(page.getByRole('textbox', { name: 'Buscar publicaciones' })).toHaveValue('Pequeños momentos, grandes historias ✨');
  64  | });
  65  | 
  66  | test('aplica presets, rechaza rangos inválidos y permite un rango de un día', async ({ page }) => {
  67  |   await page.goto('/');
  68  |   await page.getByRole('button', { name: /Últimos 30 días/ }).click();
  69  |   await page.getByRole('button', { name: 'Últimos 7 días' }).click();
  70  |   await expect(page.getByRole('button', { name: /Últimos 7 días/ })).toBeVisible();
  71  |   await page.getByRole('button', { name: /Últimos 7 días/ }).click();
  72  |   await page.getByRole('button', { name: 'Personalizado' }).click();
  73  |   const from = page.getByLabel('Fecha inicial');
  74  |   const to = page.getByLabel('Fecha final');
  75  |   await from.fill('2026-10-25');
  76  |   await to.fill('2026-10-20');
  77  |   await expect(page.getByRole('alert')).toContainText('anterior o igual');
  78  |   await expect(page.getByRole('button', { name: 'Aplicar período' })).toBeDisabled();
  79  |   await expect(page.getByRole('button', { name: '1 oct — 31 oct' })).toBeVisible();
  80  | 
  81  |   await from.fill('2026-10-21');
  82  |   await to.fill('2026-10-21');
  83  |   await expect(page.getByRole('alert')).toHaveCount(0);
  84  |   await page.getByRole('button', { name: 'Aplicar período' }).click();
  85  |   await expect(page.getByRole('button', { name: '21 oct' })).toBeVisible();
  86  |   await expect(page.locator('.followers-card .recharts-dot')).toHaveCount(3);
  87  | });
  88  | 
  89  | test('pagina y filtra la tabla de publicaciones; reinicia la página al filtrar', async ({ page }) => {
  90  |   await page.goto('/reports');
  91  |   await expect(page.getByText('Página 1 de 2')).toBeVisible();
  92  |   await page.getByLabel('Filas por página').selectOption('3');
  93  |   await expect(page.getByText('Página 1 de 2')).toBeVisible();
  94  |   await page.getByRole('button', { name: 'Página siguiente' }).click();
  95  |   await expect(page.getByText('Página 2 de 2')).toBeVisible();
  96  |   await page.getByLabel('Filas por página').selectOption('5');
  97  |   await expect(page.getByText('Página 1 de 2')).toBeVisible();
  98  |   await page.getByRole('button', { name: 'Página siguiente' }).click();
  99  |   await expect(page.getByText('Página 2 de 2')).toBeVisible();
  100 |   await page.getByLabel('Filtrar por canal').selectOption('instagram');
  101 |   await expect(page.getByText('Página 1 de 1')).toBeVisible();
  102 |   await expect(page.locator('.report-table tbody tr')).toHaveCount(2);
  103 |   await expect(page.getByRole('button', { name: 'Página anterior' })).toBeDisabled();
  104 | });
  105 | 
  106 | test('busca, pagina, edita y desactiva usuarios localmente', async ({ page }) => {
  107 |   await page.goto('/users');
  108 |   await expect(page.getByText('Página 1 de 2')).toBeVisible();
  109 |   await page.getByRole('button', { name: 'Página siguiente' }).click();
  110 |   await expect(page.getByText('Mateo Cruz')).toBeVisible();
  111 |   await page.getByLabel('Filas por página').selectOption('5');
  112 |   await expect(page.getByText('Página 1 de 1')).toBeVisible();
  113 |   await page.getByPlaceholder('Buscar usuario').fill('Sofía');
  114 |   await expect(page.getByText('Página 1 de 1')).toBeVisible();
  115 |   await page.getByRole('button', { name: 'Acciones de Sofía Ramírez' }).click();
  116 |   await page.getByRole('button', { name: 'Editar información' }).click();
  117 |   await page.getByPlaceholder('Ej. Andrea López').fill('Sofía Auditada');
  118 |   await page.getByRole('button', { name: 'Guardar cambios' }).click();
  119 |   await expect(page.getByText('Sofía Auditada')).toBeVisible();
  120 |   await page.getByRole('button', { name: 'Acciones de Sofía Auditada' }).click();
  121 |   await page.getByRole('button', { name: 'Desactivar usuario' }).click();
  122 |   await expect(page.getByText('Inactivo')).toBeVisible();
  123 | });
  124 | 
  125 | test('conecta y desconecta un canal localmente', async ({ page }) => {
  126 |   await page.goto('/connections');
  127 |   const whatsappCard = page.locator('.connection-card').filter({ hasText: 'WhatsApp' });
  128 |   await expect(whatsappCard.getByText('Desconectado')).toBeVisible();
  129 |   await whatsappCard.getByRole('button', { name: 'Conectar' }).click();
  130 |   await expect(whatsappCard.getByText('Conectado')).toBeVisible();
  131 |   await whatsappCard.getByRole('button', { name: 'Desconectar' }).click();
  132 |   await expect(whatsappCard.getByText('Desconectado')).toBeVisible();
  133 |   await page.getByRole('button', { name: 'Actualizar estados' }).click();
  134 |   await expect(page.getByRole('status')).toContainText('fechas de sincronización');
  135 |   await page.getByRole('button', { name: 'Agregar conexión' }).click();
  136 |   await expect(page.getByRole('status')).toContainText('fase futura');
  137 | });
  138 | 
  139 | test('permite explorar y enviar mensajes simulados en WhatsApp', async ({ page }) => {
```