# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: phase-1.spec.js >> renderiza paths de Recharts con geometría tras la animación
- Location: e2e/phase-1.spec.js:203:1

# Error details

```
Error: expect(locator).toBeAttached() failed

Locator: locator('.recharts-line-curve').first()
Expected: attached
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeAttached" locator('.recharts-line-curve').first() with timeout 5000ms
  - waiting for locator('.recharts-line-curve').first()

```

```yaml
- main:
  - text: am
  - heading "Inicia sesión" [level=1]
  - paragraph: Ingresa a AI Marketing Manager con tu cuenta.
  - text: Correo electrónico
  - textbox "Correo electrónico"
  - text: Contraseña
  - textbox "Contraseña"
  - button "Ingresar"
  - link "Continuar con Google":
    - /url: /api/auth/google
  - link "¿Olvidaste tu contraseña?":
    - /url: /forgot-password
```

# Test source

```ts
  106 |   await expect(page.getByRole('button', { name: 'Página anterior' })).toBeDisabled();
  107 | });
  108 | 
  109 | test('busca, pagina, edita y desactiva usuarios localmente', async ({ page }) => {
  110 |   await page.goto('/users');
  111 |   await expect(page.getByText('Página 1 de 2')).toBeVisible();
  112 |   await page.getByRole('button', { name: 'Página siguiente' }).click();
  113 |   await expect(page.getByText('Mateo Cruz')).toBeVisible();
  114 |   await page.getByLabel('Filas por página').selectOption('5');
  115 |   await expect(page.getByText('Página 1 de 1')).toBeVisible();
  116 |   await page.getByPlaceholder('Buscar usuario').fill('Sofía');
  117 |   await expect(page.getByText('Página 1 de 1')).toBeVisible();
  118 |   await page.getByRole('button', { name: 'Acciones de Sofía Ramírez' }).click();
  119 |   await page.getByRole('button', { name: 'Editar información' }).click();
  120 |   await page.getByPlaceholder('Ej. Andrea López').fill('Sofía Auditada');
  121 |   await page.getByRole('button', { name: 'Guardar cambios' }).click();
  122 |   await expect(page.getByText('Sofía Auditada')).toBeVisible();
  123 |   await page.getByRole('button', { name: 'Acciones de Sofía Auditada' }).click();
  124 |   await page.getByRole('button', { name: 'Desactivar usuario' }).click();
  125 |   await expect(page.getByText('Inactivo')).toBeVisible();
  126 | });
  127 | 
  128 | test('conecta y desconecta un canal localmente', async ({ page }) => {
  129 |   await page.goto('/connections');
  130 |   const whatsappCard = page.locator('.connection-card').filter({ hasText: 'WhatsApp' });
  131 |   await expect(whatsappCard.getByText('Desconectado')).toBeVisible();
  132 |   await whatsappCard.getByRole('button', { name: 'Conectar' }).click();
  133 |   await expect(whatsappCard.getByText('Conectado')).toBeVisible();
  134 |   await whatsappCard.getByRole('button', { name: 'Desconectar' }).click();
  135 |   await expect(whatsappCard.getByText('Desconectado')).toBeVisible();
  136 |   await page.getByRole('button', { name: 'Actualizar estados' }).click();
  137 |   await expect(page.getByRole('status')).toContainText('fechas de sincronización');
  138 |   await page.getByRole('button', { name: 'Agregar conexión' }).click();
  139 |   await expect(page.getByRole('status')).toContainText('fase futura');
  140 | });
  141 | 
  142 | test('permite explorar y enviar mensajes simulados en WhatsApp', async ({ page }) => {
  143 |   await page.goto('/whatsapp');
  144 |   await page.getByPlaceholder('Buscar conversación').fill('Carlos');
  145 |   await page.getByRole('button', { name: /Carlos López/ }).click();
  146 |   await expect(page.locator('.thread-heading')).toContainText('Carlos López');
  147 |   await page.getByRole('button', { name: 'Llamar' }).click();
  148 |   await expect(page.getByRole('status')).toContainText('no se realizan');
  149 |   await page.getByRole('button', { name: 'Cerrar' }).click();
  150 |   await page.getByRole('button', { name: 'Adjuntar archivo' }).click();
  151 |   await expect(page.getByRole('status')).toContainText('no se cargan');
  152 |   await page.getByRole('button', { name: 'Cerrar' }).click();
  153 |   await page.getByRole('button', { name: 'Insertar emoji' }).click();
  154 |   await expect(page.getByPlaceholder(/Escribe un mensaje de demostración/)).toHaveValue('😊');
  155 |   await page.getByPlaceholder(/Escribe un mensaje de demostración/).fill('Prueba local');
  156 |   await page.getByRole('button', { name: 'Enviar mensaje' }).click();
  157 |   await expect(page.getByText('Prueba local')).toBeVisible();
  158 | });
  159 | 
  160 | test('los controles de perfil, notificaciones, perfiles de canal y vista general responden', async ({ page }) => {
  161 |   await page.goto('/');
  162 |   await page.getByRole('button', { name: 'Notificaciones' }).click();
  163 |   await page.getByRole('button', { name: 'Marcar leídas' }).click();
  164 |   await expect(page.locator('.notification-button i')).toHaveCount(0);
  165 |   await page.getByRole('button', { name: /Sofía Ramírez/ }).click();
  166 |   await page.getByRole('button', { name: 'Preferencias' }).click();
  167 |   await expect(page).toHaveURL(/\/settings$/);
  168 |   await page.getByRole('button', { name: 'Guardar cambios' }).click();
  169 |   await expect(page.getByRole('status')).toContainText('Preferencias simuladas guardadas');
  170 |   await page.goto('/channels/facebook');
  171 |   await page.getByRole('button', { name: 'Abrir perfil' }).click();
  172 |   await expect(page.getByRole('status')).toContainText('no se abre una cuenta real');
  173 |   await page.goto('/comparison');
  174 |   await page.getByRole('button', { name: 'Vista general' }).click();
  175 |   await expect(page.getByRole('status')).toContainText('Vista general');
  176 | });
  177 | 
  178 | test('responde con el mock conversacional y expande el historial de IA', async ({ page }) => {
  179 |   await page.goto('/ai');
  180 |   await page.getByRole('button', { name: '¿Qué contenido funcionó mejor?' }).click();
  181 |   await expect(page.getByText('Según los datos de demostración', { exact: false })).toBeVisible();
  182 |   await page.getByRole('button', { name: 'Ver todo' }).click();
  183 |   await expect(page.getByText('Tendencias de audiencia')).toBeVisible();
  184 |   await expect(page.getByRole('button', { name: 'Ver menos' })).toBeVisible();
  185 | });
  186 | 
  187 | test('abre el menú móvil y permite navegar', async ({ page }) => {
  188 |   await page.setViewportSize({ width: 390, height: 844 });
  189 |   await page.goto('/');
  190 |   await page.getByRole('button', { name: 'Abrir navegación' }).click();
  191 |   await expect(page.locator('.sidebar')).toHaveClass(/sidebar-mobile-open/);
  192 |   await page.getByRole('link', { name: 'Instagram', exact: true }).click();
  193 |   await expect(page).toHaveURL(/\/channels\/instagram$/);
  194 |   await expect(page.locator('.sidebar')).not.toHaveClass(/sidebar-mobile-open/);
  195 | });
  196 | 
  197 | test('el buscador global también está disponible con viewport móvil', async ({ page }) => {
  198 |   await page.setViewportSize({ width: 390, height: 844 });
  199 |   await page.goto('/');
  200 |   await page.getByRole('button', { name: 'Buscar' }).click();
  201 |   await page.getByRole('textbox', { name: 'Buscar módulos, usuarios y publicaciones' }).fill('TikTok');
  202 |   await page.getByRole('option').filter({ hasText: 'Módulo' }).click();
  203 |   await expect(page).toHaveURL(/\/channels\/tiktok$/);
  204 | });
  205 | 
> 206 | test('renderiza paths de Recharts con geometría tras la animación', async ({ page }) => {
      |                      ^ Error: expect(locator).toBeAttached() failed
  207 |   await page.goto('/');
  208 |   const path = page.locator('.recharts-line-curve').first();
  209 |   await expect(path).toBeAttached();
  210 |   await expect.poll(async () => (await path.getAttribute('d'))?.length || 0).toBeGreaterThan(20);
  211 |   await page.waitForTimeout(2200);
  212 |   await expect(path).toBeVisible();
  213 |   expect(await path.getAttribute('stroke')).toMatch(/^#/);
  214 |   await expect.poll(async () => {
  215 |     const dash = await path.getAttribute('stroke-dasharray');
  216 |     return dash === null || !dash.startsWith('0px');
  217 |   }).toBe(true);
  218 | });
  219 | 
```